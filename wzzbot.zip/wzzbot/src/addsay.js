const addsay = () => { 
	return `
	
	*Adicionar mensagem*
	
	mensagem salva com sucesso!
	

obrigado !`
}
exports.addsay = addsay

const addfoto = () => { 
	return `
	
	*ADICIONAR BASE DE DADOS FOTO*
	
	fotos salvas com sucesso!
	

obrigado !`
}
exports.addfoto = addfoto

const cekvip = () => { 
	return `           
──────────────────
*Nome do bot* :  WZZ
──────────────────
        『 *𝐕𝐈𝐏 𝐔𝐒𝐄𝐑* 』
──────────────────
• *Status*    : *ATIVO*
────────────────── 
*Status Bot:* *Online*
──────────────────

*ai sim cria, vc é um membro vip 👨🏿‍💻`
}
exports.cekvip = cekvip
